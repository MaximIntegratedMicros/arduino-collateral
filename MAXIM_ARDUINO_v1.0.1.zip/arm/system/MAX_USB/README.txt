This is a precompile library. If you make changes to any file(s) in source or include directory, you must rebuild the library.

Open MINGW for Windows or terminal for Mac/Linux, navigate to this directory and run:

$ make clean
$ make lib
$ rm Build/*.d Build/*.o
